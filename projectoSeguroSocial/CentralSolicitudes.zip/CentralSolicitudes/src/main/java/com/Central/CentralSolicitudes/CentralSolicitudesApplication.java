package com.Central.CentralSolicitudes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CentralSolicitudesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CentralSolicitudesApplication.class, args);
	}

}
