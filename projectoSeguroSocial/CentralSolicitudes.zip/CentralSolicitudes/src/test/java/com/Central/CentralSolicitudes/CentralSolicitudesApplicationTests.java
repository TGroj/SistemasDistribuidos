package com.Central.CentralSolicitudes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CentralSolicitudesApplicationTests {

	@Test
	void contextLoads() {
	}

}
