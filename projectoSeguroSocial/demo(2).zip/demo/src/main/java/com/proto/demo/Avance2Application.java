package com.proto.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Avance2Application {

	public static void main(String[] args) {
		SpringApplication.run(Avance2Application.class, args);
	}

}
